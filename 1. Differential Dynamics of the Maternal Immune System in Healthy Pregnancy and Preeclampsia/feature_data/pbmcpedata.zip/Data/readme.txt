The following data are provided as an rda file. These can be loaded in a recent version of R using the command: load(‘Data.rda’). The following information is provided:
GA: Gestational age at time of sampling in weeks.
pe: Preeclampsia diagnosis (2) or control (1) groups.
data: cell populations / signaling / stimulations (as columns) for each sample (as rows). Row names and column names provide sample names and feature names, respectively. 